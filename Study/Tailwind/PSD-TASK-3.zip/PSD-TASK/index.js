$(document).ready(function () {
    $('.sliderContainer').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: true,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    arrows: true,
                    slidesToShow: 1,
                    autoplay: true,
                    autoplaySpeed: 2000,
                }
            },
            {
                breakpoint: 1280,
                settings: {
                    arrows: true,
                    slidesToShow: 1
                }
            }]
    });

    $('.events').slick({
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: false,
        fade: true,
    });

    $(window).scroll(function () {
        let scroll = $(window).scrollTop();
        const cross = document.getElementById("cross");
        const menu = document.getElementById("icon");
        const x = document.getElementById("myLinks");
        if (scroll) {
            $("#sticky-header").addClass("bg-scroll");
            $("#sticky-content").addClass("bg-content-scroll")
        } else {
            $("#sticky-header").removeClass("bg-scroll");
            $("#sticky-content").removeClass("bg-content-scroll")
            x.style.display = "none";
            cross.style.display = "none";
            menu.style.display = "block";
        }
    });
});

function myFunction () {
    const x = document.getElementById("myLinks");
    const cross = document.getElementById("cross");
    const menu = document.getElementById("icon");
    if (x.style.display === "block") {
        x.style.transform = "scaleX(0)";
        setTimeout(() => {
            x.style.display = "none";
            cross.style.display = "none";
            menu.style.display = "block";
            $("#sticky-header").removeClass("bg-scroll");
        }, 300);
    } else {
        x.style.display = "block";
        cross.style.display = "block";
        menu.style.display = "none";
        setTimeout(() => {
            $("#sticky-header").addClass("bg-scroll");
            x.style.transform = "scaleX(1)";
        }, 10);
    }
}



