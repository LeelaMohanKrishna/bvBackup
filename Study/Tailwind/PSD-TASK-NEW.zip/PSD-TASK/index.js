$(document).ready(function () {
    $('.sliderContainer').slick({
        centerMode: true,
        slidesToShow: 3,
        arrows: true,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    arrows: true,
                    centerMode: false,
                    slidesToShow: 1,
                    autoplay: true,
                    autoplaySpeed: 1500,
                }
            },
            {
                breakpoint: 1280,
                settings: {
                    arrows: true,
                    centerMode: false,
                    slidesToShow: 1
                }
            }]
    });

    $('.events').slick({
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        fade: true,
    });

    $(window).scroll(function () {
        let scroll = $(window).scrollTop();
        if (scroll >= $('#sticky-header').outerHeight()) {
            $("#sticky-header").addClass("bg-scroll");
            // $("#sticky-header").removeClass("bg-no-scroll");
        } else {
            // $("#sticky-header").addClass("bg-no-scroll");
            $("#sticky-header").removeClass("bg-scroll");
        }
    });
});

function myFunction () {
    const x = document.getElementById("myLinks");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}



